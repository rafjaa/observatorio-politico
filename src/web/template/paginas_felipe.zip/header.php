<meta charset="utf-8">
<title>Obeservatório Político</title>
<link href="css/nv.d3.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link href="css/template.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,900" rel="stylesheet">
<script src="js/jquery-3.2.1.slim.min.js" ></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/d3.min.js" charset="utf-8"></script>
<script src="js/nv.d3.min.js"></script>
