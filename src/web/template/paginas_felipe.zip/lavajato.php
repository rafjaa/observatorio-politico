<!DOCTYPE html>
<html>
<head>
<?php include"header.php"; ?>
<?php //include"funcoes.php"; ?>
<script src="js/lavajato.js"></script>
</head>
<body>

<?php include"menu.php";?>

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <br/>
            <h1 class="text-uppercase">Operação Lava Jato</h1>
            <h3>Os políticos que mais aparecem nas notícias de investição da Lava Jato. </h3>
        </div>
    </div>
    <hr/>

    <div class="row">
        <div class="col">
            <div class="chart1 chart">
                <svg></svg>
            </div>
        </div>
    </div>
    <hr/>

    <div class="row">
        <div class="col-sm-5">
            <div class="img-intro">
                <img src="images/lula.jpg" alt="" />
                <h2>Lula</h2>
            </div>
            <h2 class="text-uppercase">O nome mais citado!</h2>
            <h2 class="light">Das <b>3320</b> notícias em que aparece, <b>1041</b> citam a Lava Jato.</h2>
        </div>
        <div class="col-sm-7">
            <br/>
            <h5 class="text-center">Quantides de notícias sobre a Lava Jato por site.</h5>
            <br/>
            <div class="chart8 size2 chart box">
                <svg></svg>
            </div>
        </div>
    </div>
    <hr/>

</div>

</body>
</html>
