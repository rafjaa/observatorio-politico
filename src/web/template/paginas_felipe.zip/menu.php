<div class="header">
    <div class="container">
    <ul class="nav justify-content">
        <li class="nav-item">
            <a class="nav-link" href="index.php">Pré-Candidatos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="partidos.php">Partidos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="lavajato.php">Lava Jato</a>
        </li>
    </ul>
    </div>
</div>
