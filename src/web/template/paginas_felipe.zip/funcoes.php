<?php

$mongo = new MongoDB\Driver\Manager("mongodb://localhost:27017");
$db = "tpbd";
$collection = "noticias";
$dbColle = 'tpbd.noticias';

function relevanciaGeral($entidade){
    $regex = new MongoDB\BSON\Regex($entidade);

    $filter = ['$or' => [["entidades.tag" => strtoupper($entidade),"entidades.freq" => ['$gt' => 1]],['titulo' => $regex]]];
    $command = new MongoDB\Driver\Command(["count" => "noticias", "query" => $filter]);
    $result = $GLOBALS['mongo']->executeCommand($GLOBALS['db'], $command);
    $result = current($result->toArray());
    $count = $result->n;
    return $count;
}

function relevanciaSite($entidade,$site){
    $regex = new MongoDB\BSON\Regex($entidade);
    $regex2 = new MongoDB\BSON\Regex($site);
    $filter = ['$and' => [ ['$or' => [["entidades.tag" => strtoupper($entidade),"entidades.freq" => ['$gt' => 1]],['titulo' => $regex]]],['url' => $regex2] ]];
    $command = new MongoDB\Driver\Command(["count" => "noticias", "query" => $filter]);
    $result = $GLOBALS['mongo']->executeCommand($GLOBALS['db'], $command);
    $result = current($result->toArray());
    $count = $result->n;
    return $count;
}

function mediaGeral($entidade){
    $regex = new MongoDB\BSON\Regex($entidade);
    $soma = 0;
    $count = 0;
    $filter = ['$or' => [["entidades.tag" => strtoupper($entidade),"entidades.freq" => ['$gt' => 1]],['titulo' => $regex]]];
    $query = new \MongoDB\Driver\Query($filter);
    $result = $GLOBALS['mongo']->executeQuery($GLOBALS['dbColle'], $query);
    foreach ($result as $item) {
        $soma = $soma + $item->polaridade->compound;
        $count++;
    }
    return round($soma/$count, 4);
}

function mediaSite($entidade,$site){
    $regex = new MongoDB\BSON\Regex($entidade);
    $regex2 = new MongoDB\BSON\Regex($site);
    $soma = 0;
    $count = 0;
    $filter = ['$and' => [ ['$or' => [["entidades.tag" => strtoupper($entidade),"entidades.freq" => ['$gt' => 1]],['titulo' => $regex]]],['url' => $regex2] ]];
    $query = new \MongoDB\Driver\Query($filter);
    $result = $GLOBALS['mongo']->executeQuery($GLOBALS['dbColle'], $query);
    foreach ($result as $item) {
        $soma = $soma + $item->polaridade->compound;
        $count++;
    }
    return round($soma/$count, 4);
}

$candidatos = array("Lula","Haddad","Ciro Gomes","Marina","Joaquim Barbosa","Doria","Bolsonaro");
$sites = array("agenciabrasil.ebc.com.br","g1.globo.com","nominuto.com","otempo.com.br","politicalivre.com.br");
$temas = array("EDUCAÇÃO","SAÚDE","SEGURANÇA","EMPREGO");
$partidos = array("PT","PSDB","PMDB","PP","PDT","DEM","PSB");

function plotaTabela($entidades,$sites){
    echo "<table class='table'>";
    echo "<tr>";
    echo "<td>Candidatos</td>";
    foreach ($sites as $site) {
        echo "<td>$site</td>";
    }
    echo "<td>Media</td>";
    echo "<td>Quantidade</td>";
    echo "</tr>";
    foreach ($entidades as $entidade) {
        echo "<tr>";
        echo "<td>$entidade</td>";
        foreach($sites as $site){
            echo "<td>";
                echo relevanciaSite($entidade,$site);
            echo "</td>";
        }
        $media = mediaGeral($entidade);
        echo "<td>$media</td>";
        $qtdd = relevanciaGeral($entidade);
        echo "<td>$qtdd</td>";
        echo "</tr>";
    }
    echo "</table>";
}

function plotaTabela2($entidades,$sites){
    echo "<table class='table'>";
    echo "<tr>";
    echo "<td></td>";
    foreach ($entidades as $entidade) {
        echo "<td>$entidade</td>";
    }
    echo "</tr>";
    foreach ($sites as $site) {
        echo "<tr>";
        echo "<td>$site</td>";
        foreach($entidades as $entidade){
            echo "<td>";
                echo relevanciaSite($entidade,$site);
            echo "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
}


?>
